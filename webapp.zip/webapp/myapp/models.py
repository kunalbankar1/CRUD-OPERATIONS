from django.db import models


class Employee(models.Model):
    eid = models.CharField(max_length=20)
    Ename = models.CharField(max_length=40)
    Eemail = models.EmailField()
    Econtact = models.CharField(max_length=50)
